<?php

defined('_JEXEC') or die;

if(!defined('DS')){
    define("DS", DIRECTORY_SEPARATOR);
}

class MyRECartControllersCategories extends JControllerLegacy
{
    function display($cachable = false, $urlparams = array()){
        JRequest::setVar("view", "categories");
        parent::display($cachable, $urlparams);
    }
    
    function add(){
        JRequest::setVar("view", "category");
        parent::display();
    }
            
    function save(){
        JRequest::checkToken() or die("no token / invalid token found");
        $data = $this->input->post->get('jform', array(), 'array');
        
        $model = $this->getModel('categories');
        if($model->save($data)){
            $this->setMessage("Category Saved succesfully");
        }else{
            JError::raise('', "Save faild <br/>", implode("<br/>", $model->getError()));
        }
        
        $this->setRedirect(JRoute::_("index.php?option=com_myrecart&c=category"));
    }
    
    function edit(){
        JRequest::setVar("view", "categories");
        parent::display();
    }
    
    
}