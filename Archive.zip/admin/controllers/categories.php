<?php

defined('_JEXEC') or die;

if(!defined('DS')){
    define("DS", DIRECTORY_SEPARATOR);
}

class MyRECartControllersCategories extends JControllerLegacy
{
    function display($cachable = false, $urlparams = array()){
        JFactory::getApplication()->input->set("view", "categories");
        parent::display($cachable, $urlparams);
    }
    
    function add(){
        JFactory::getApplication()->input->set("view", "category");
        parent::display();
    }
            
    function save(){
        JSession::checkToken() or die("no token / invalid token found");
        $data = $this->input->post->get('jform', array(), 'array');
        
        $model = $this->getModel('categories');
        if($model->save($data)){
            $this->setMessage("Category Saved succesfully");
        }else{
            JError::raise('', "Save faild <br/>", implode("<br/>", $model->getError()));
        }
        
        $this->setRedirect(JRoute::_("index.php?option=com_myrecart&c=category"));
    }
    
    function edit(){
        JFactory::getApplication()->input->set("view", "categories");
        parent::display();
    }
    
    
}