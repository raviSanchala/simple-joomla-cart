<?php

defined('_JEXEC') or die;

if(!defined('DS')){
    define("DS", DIRECTORY_SEPARATOR);
}

class MyRECartControllersProduct extends JControllerLegacy
{
    function display($cachable = false, $urlparams = array()){
        JRequest::setVar("view", "product");
        parent::display($cachable, $urlparams);
    }
    
    function add(){
        JRequest::setVar("view", "product");
        parent::display();
    }
            
    function save(){
        JRequest::checkToken() or die("no token / invalid token found");
        $data = $this->input->post->get('jform', array(), 'array');
        
        $model = $this->getModel('product');
        if($model->save($data)){
            $this->setMessage("Product Saved succesfully");
        }else{
            JError::raise('', "Save faild <br/>", implode("<br/>", $model->getError()));
        }
        
        $this->setRedirect(JRoute::_("index.php?option=com_myrecart&c=product"));
    }
    
    function edit(){
        JRequest::setVar("view", "product");
        parent::display();
    }
    
    function delete(){
        
        JRequest::checkToken() or die();
        
        $cid = JRequest::getVar('cid');
        $model = $this->getModel('product');
        
        foreach ($cid as $id){
            if($model->delete($id)){
                $this->setMessage("Product Deleted succesfully");
            }else{
                JError::raise('', "Save faild <br/>", implode("<br/>", $model->getError()));
            }
        }
        
        $this->setRedirect(JRoute::_("index.php?option=com_myrecart&c=product"));
    }
}