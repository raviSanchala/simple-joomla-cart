<?php

defined('_JEXEC') or die;

if(!defined('DS')){
    define("DS", DIRECTORY_SEPARATOR);
}

class MyRECartControllersProducts extends JControllerLegacy{
    
    function display($cachable = false, $urlparams = array()){   
        JRequest::setVar("view", "products");
        parent::display();
    }
    
    function add(){
        JRequest::setVar("view", "product");
        parent::display();
    }
    
    function edit(){
        JRequest::setVar("view", "product");
        parent::display();
    }
    
    function delete(){
        JRequest::checkToken() or die();
        
        $cid = JRequest::getVar('cid');
        $model = $this->getModel('product');
        
        foreach ($cid as $id){
            if($model->delete($id)){
                $this->setMessage("Product Deleted succesfully");
            }else{
                JError::raise('', "Save faild <br/>", implode("<br/>", $model->getError()));
            }
        }
        
        $this->setRedirect(JRoute::_("index.php?option=com_myrecart&c=product"));
    }
    
}
