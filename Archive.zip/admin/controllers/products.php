<?php

defined('_JEXEC') or die;

if(!defined('DS')){
    define("DS", DIRECTORY_SEPARATOR);
}

class MyRECartControllersProducts extends JControllerLegacy{
    
    function display($cachable = false, $urlparams = array()){   
        JFactory::getApplication()->input->set("view", "products");
        parent::display();
    }
    
    function add(){
        JFactory::getApplication()->input->set("view", "product");
        parent::display();
    }
    
    function edit(){
        JFactory::getApplication()->input->set("view", "product");
        parent::display();
    }
    
    function delete(){
        
        
        JSession::checkToken() or die();
        
        $cid = JInput::get('cid');
        $model = $this->getModel('product');
        
        foreach ($cid as $id){
            if($model->delete($id)){
                $this->setMessage("Product Deleted succesfully");
            }else{
                JError::raise('', "Save faild <br/>", implode("<br/>", $model->getError()));
            }
        }
        
        $this->setRedirect(JRoute::_("index.php?option=com_myrecart&c=products"));
    }
    
}
