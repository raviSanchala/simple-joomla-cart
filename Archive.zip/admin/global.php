<?php

defined('_JEXEC') or die;

define('HOSTING_IMAGEURL', Juri::root().'administrator/components/com_myrecart/assets/image/');
define('HOSTING_IMAGEPATH', JPATH_COMPONENT_ADMINISTRATOR.DS.'assets'.DS.'image'.DS);