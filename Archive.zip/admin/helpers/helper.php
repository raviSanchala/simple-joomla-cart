<?php
defined('_JEXEC') or die;

class Helper
{
    function addSubmenu($vName){
        JHtmlSidebar::addEntry(JText::_('products'), 'index.php?option=com_myrecart&c=products', $vName=='products');
    }
}