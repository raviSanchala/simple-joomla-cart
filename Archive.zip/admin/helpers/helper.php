<?php
defined('_JEXEC') or die;

class Helper
{
    function addSubmenu($vName){
        JHtmlSidebar::addEntry(JText::_('Products'), 'index.php?option=com_myrecart&c=products', $vName=='products');
        JHtmlSidebar::addEntry(JText::_('Categories'), 'index.php?option=com_myrecart&c=category', $vName=='category');
    }
}