<?php

defined('_JEXEC') or die;

class MyRECartModelCategories extends JModelForm
{
    function getForm($data = array(), $loadData = true){
        $options = array('control'=>"jform", "load_data"=>$loadData);
        
        $form = $this->loadForm('com_myrecart.categories', 'categories', $options);
        
        if(empty($form)){
            return false;
        }else{
            return $form;
        }
    }
    
    function save($data){
        $db = JFactory::getDbo();
        $obj = (object) $data;
        
        try{
            if($obj->id){
                $db->updateObject("#__myrecart_categories", $obj, 'id');
            }else{
                $db->insertObject("#__myrecart_categories", $obj, 'id');
            }
            
        }catch (RuntimeException $exc){
            $this->setError($exc->getMessage());
            return false;
        }
        
        return true;
    }
    
    public function getItem(){
        $pk = JRequest::getVar('cid');
        if(is_array($pk)){
            $pk = $pk[0];
        }
        
        if($pk == ''){
            return false;
        }
        
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('*')->from('#__myrecart_categories')->where($db->quoteName('id')."=".$db->quote($pk));
        $db->setQuery($query);
        
        $db->query();
        
        return $db->loadObject();
    }
    
    protected function loadFormData(){
        $data = $this->getItem();
        return $data;
    }
    
    
    
}