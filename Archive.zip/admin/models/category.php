<?php
defined('_JEXEC') or die;

class MyRECartModelCategory extends JModelList
{
    
    public function __construct($config = array()) {
        if(empty($config['filter_fields'])){
            $config['filter_fields'] = array(
                "category_name" =>  "category_name",
                "category_slug" =>  "category_slug"
            );
        }
        
        parent::__construct($config);
    }
    
    protected function populateState($ordering = null, $direction = null){
        $search = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
        $this->setState('filter.search', $search);
        
        parent::populateState('id', 'asc');
    }
    
    protected function getListQuery(){
        
        $db = $this->getDbo();
        $query = $db->getQuery(true);
        
        $query->select('*')->from("#__myrecart_categories");
        
        
        if($this->getState['filter.search'] !== ''){
            $token = $db->quote("%".$db->escape($this->getState('filter.search'))."%");
            $searches = array();
            
            $searches[] = 'category_name LIKE '.$token;
            $searches[] = 'category_slug LIKE '.$token;
            
            $query->where('('. implode(' OR ', $searches).')');
        }
        
        $query->order($db->escape($this->getState('list.ordering')) .' '.$db->escape($this->getState('list.direction', 'ASC')));
        
        return $query;
    }
    
    
}