<?php

defined('_JEXEC') or die;
jimport('joomla.filesystem.file');
class MyRECartModelProduct extends JModelForm
{
    function getForm($data = array(), $loadData = true){
        $options = array('control'=>"jform", "load_data"=>$loadData);
        
        $form = $this->loadForm('com_myrecart.product', 'product', $options);
        
        if(empty($form)){
            return false;
        }else{
            return $form;
        }
    }
    
    function save($data){
        $db = JFactory::getDbo();
        $obj = (object) $data;
        $product_img = '';
        if(!empty($_FILES['jform']['name']['product_img'])){
            $ext = JFile::getExt($_FILES['jform']['name']['product_img']);
            $product_img = md5($_FILES['jform']['name']['product_img'].time()).".".$ext;
            
            $dest = HOSTING_IMAGEPATH.$product_img;
            JFile::copy($_FILES['jform']['tmp_name']['product_img'], $dest);
        }
        
        try{
            if($obj->id){
                $db->updateObject("#__myrecart_products", $obj, 'id');
            }else{
                $db->insertObject("#__myrecart_products", $obj, 'id');
                $lastProduct_id = $db->insertid();
                if($product_img != ''){
                    $media_data_arr = array(
                                    "product_id"    =>  $lastProduct_id,
                                    "product_img"  =>  $product_img,
                                    "createdDate"   =>  date("Y-m-d H:i:s")
                        );
                    $media_data_obj = (object) $media_data_arr;
                    $db->insertObject("#__myrecart_product_media", $media_data_obj, 'id');
                }
                
            }
            
        }catch (RuntimeException $exc){
            $this->setError($exc->getMessage());
            return false;
        }
        
        return true;
    }
    
    public function getItem(){
        $pk = JInput::get('cid');
        if(is_array($pk)){
            $pk = $pk[0];
        }
        
        if($pk == ''){
            return false;
        }
        
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('*')->from('#__myrecart_products')->where($db->quoteName('id')."=".$db->quote($pk));
        $db->setQuery($query);
        
        $db->query();
        
        return $db->loadObject();
    }
    
    protected function loadFormData(){
        $data = $this->getItem();
        return $data;
    }
    
    public function delete($id){
        
        $db = $this->getDbo();
        $query = $db->getQuery(true);
        
        try{
            $query->delete("#__myrecart_products")->where($db->quoteName('id')."=".$db->quote($id));
            $db->setQuery($query);
            $db->execute();
        } catch (RuntimeException $ex) {
            $this->setError($ex->getMessage());
            return false;
        }
        
        return true;
    }
    
    
}