<?php
defined('_JEXEC') or die;

class MyRECartModelProducts extends JModelList
{
    
    public function __construct($config = array()) {
        if(empty($config['filter_fields'])){
            $config['filter_fields'] = array(
                "product_name" =>  "product_name",
                "product_slug" =>  "product_slug",
            );
        }
        
        parent::__construct($config);
    }
    
    protected function populateState($ordering = null, $direction = null){
        $search = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
        $this->setState('filter.search', $search);
        
        parent::populateState('id', 'asc');
    }
    
    protected function getListQuery(){
        
        $db = $this->getDbo();
        $query = $db->getQuery(true);
        
        $query->select(array('p.*', 'c.category_name', 'pm.product_img'))
                ->from($db->quoteName("#__myrecart_products", 'p'))
                ->join('INNER', $db->quoteName('#__myrecart_categories', 'c') . ' ON (' . $db->quoteName('c.id') . ' = ' . $db->quoteName('p.category_id') . ')')
                ->join('LEFT', $db->quoteName('#__myrecart_product_media', 'pm') . ' ON (' . $db->quoteName('pm.product_id') . ' = ' . $db->quoteName('p.id') . ')')
                ->group($db->quoteName('p.id'));
        
        if($this->getState['filter.search'] !== ''){
            $token = $db->quote("%".$db->escape($this->getState('filter.search'))."%");
            $searches = array();
            
            $searches[] = 'p.product_name LIKE '.$token;
            $searches[] = 'p.product_slug LIKE '.$token;
            $searches[] = 'c.category_name LIKE '.$token;
            
            $query->where('('. implode(' OR ', $searches).')');
        }
        
        $query->order($db->escape($this->getState('list.ordering')) .' '.$db->escape($this->getState('list.direction', 'ASC')));
        
        return $query;
    }
    
//    public function detele($id){
//        
//        $db = $this->getDbo();
//        $query = $db->getQuery(true);
//        try{
//            $query->delete("#__myrecart_products")->where($db->quoteName('id')."=".$db->quote($id));
//            $db->setQuery();
//            $db->execute();
//        } catch (RuntimeException $ex) {
//            $this->setError($ex->getMessage());
//            return false;
//        }
//        
//        return true;
//    }
}