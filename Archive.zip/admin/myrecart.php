<?php

defined('_JEXEC') or die;


if(!defined('DS')){
    define("DS", DIRECTORY_SEPARATOR);
}

require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'global.php';

$c = JFactory::getApplication()->input->post->get('c');
if($c == ''){
    $c = "categories";
}

require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers/helper.php';

$path = JPATH_COMPONENT_ADMINISTRATOR.DS.'controllers'.DS.$c.'.php';
if(file_exists($path)){
    require_once $path;
}else{
    JError::raiseError("500", JText::_('Junction component').' '.$c.' '.$path ); 
}

$classname = "MyRECartControllers".$c;
$controller = new $classname();


$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();