-- $Id: install.mysql.utf8.sql 24 2009-11-09 11:56:31Z chdemko $

DROP TABLE IF EXISTS `#__myrecart_cart`;
CREATE TABLE `#__myrecart_cart` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `price` float NOT NULL,
  `tax` float NOT NULL,
  `discount` float NOT NULL,
  `total_price` float NOT NULL,
  `createDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__myrecart_categories`;
CREATE TABLE `#__myrecart_categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(150) DEFAULT NULL,
  `category_slug` varchar(150) DEFAULT NULL,
  `category_description` text,
  `published` tinyint(1) NOT NULL,
  `add_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__myrecart_products`;
CREATE TABLE `#__myrecart_products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(150) NOT NULL,
  `product_slug` varchar(150) NOT NULL,
  `price` float NOT NULL,
  `offer_price` float NOT NULL DEFAULT '0',
  `product_description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `add_by` tinytext NOT NULL,
  `published` tinyint(1) NOT NULL,
  `createDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__myrecart_product_media`;
CREATE TABLE `#__myrecart_product_media` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_img` varchar(250) NOT NULL,
  `createdDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `cknfp_myrecart_cart`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `cknfp_myrecart_categories`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `cknfp_myrecart_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_category_id` (`category_id`);

ALTER TABLE `cknfp_myrecart_product_media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_media_id` (`product_id`);

ALTER TABLE `cknfp_myrecart_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

ALTER TABLE `cknfp_myrecart_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `cknfp_myrecart_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

ALTER TABLE `cknfp_myrecart_product_media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `cknfp_myrecart_products`
  ADD CONSTRAINT `product_category_id` FOREIGN KEY (`category_id`) REFERENCES `cknfp_myrecart_categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE `cknfp_myrecart_product_media`
  ADD CONSTRAINT `product_media_id` FOREIGN KEY (`product_id`) REFERENCES `cknfp_myrecart_products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;


CREATE TABLE `#__helloworld` (
  `id` int(11) NOT NULL auto_increment,
  `greeting` varchar(25) NOT NULL,
   PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;


