<?php
defined('_JEXEC') or die;

JHtml::_('behavior.keepalive');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

$user = JFactory::getUser();
if($user->id == 0){
    $added_by = 0;
}else{
    $added_by = 1;
}
?>
<script>
    Joomla.submitbutton = function(task){
        if (task == 'cancel' || document.formvalidator.isValid(document.id('adminForm'))){
            Joomla.submitform(task, document.getElementById('adminForm'));
        }else{
            alert("form submit");
        }
    }
</script>

<form action="<?php echo JRoute::_('index.php?option=com_myrecart&c=categories'); ?>" 
            name = "adminForm" 
            id="adminForm"
            method = "post" 
            class="form-validate form-horizontal" >

    <fieldset>
        <input name="jform[add_by]" type="hidden" value="<?php echo $added_by; ?>" />

        <?php 
        
        foreach ($this->form->getFieldset("categories_form") as $fields){ ?>
        <div class="control-group">
            <div class="control-label">
                <?php echo $fields->label; ?>
            </div>
            <div class="control">
                <?php echo $fields->input; ?>
            </div>
        </div>
        <?php } ?>
        <input type="hidden" name="task" />
        <?php echo JHtml::_('form.token'); ?>
    </fieldset>
</form>