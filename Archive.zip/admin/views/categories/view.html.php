<?php
defined('_JEXEC') or die;

class MyRECartViewCategories extends JViewLegacy
{
    function display($tpl = null){
        
        $this->form = $this->get('Form');
        $this->addToolbar();
        parent::display($tpl);
    }
    
    function addToolbar(){
        JToolbarHelper::save();
        JToolbarHelper::cancel();
    }
}