<?php
defined('_JEXEC') or die;

JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');

$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));

?>

<form action="<?php echo JRoute::_('index.php?option=com_myrecart&c=category'); ?>" name="adminForm" id="adminForm" method="post">
    <?php if(!empty($this->sidebar)) { ?>
    <div id='j-sidebar-container' class="span02">
        <?php echo $this->sidebar ?>
    </div>
    <?php } ?>
    <div id="j-sidebar-container" <?php echo !empty($this->sidebar) ? 'class=span10"' : ''; ?> >
        <div id="filter-bar" class="btn-toolbar">
            <div class="filter-search btn-group pull-left">
                <input type="text" name="filter_search" id="filter_search" placeholder="Search" value="<?php echo $this->escape($this->state->get('filter.search')) ?>" />
            </div>
            <div class="btn-group pull-left">
                <button type="submit" class="btn tip" title="Search"><i class="icon-search"></i></button>
                <button type="button" class="btn tip" onclick="document.id('filter_search').value'';this.form.submit();">
                    <i class="icon-remove"></i>
                </button>
            </div>
        </div>
        
    </div>
    
    <div class="clearfix"></div>
    
    <table class="table table-striped">
        <thead>
        <th width="1%" class="nowrap center">
            #
        </th>
        <th width="1%" class="nowrap center">
            <input type="checkbox" name="checkall-toggle" value="" title="<?php echo JText::_('JGLOBAL_CHECK_ALL') ?>" onclick="Joomla.checkAll(this)" />
        </th>
        <th width="1%" class="nowrap center">
            <?php echo JHtml::_("grid.sort", 'Published', 'published', $listDirn, $listOrder) ?>
        </th>
        <th class="nowrap center">
            <?php echo JHtml::_("grid.sort", 'Name', 'category_name', $listDirn, $listOrder) ?>
        </th>
        <th class="nowrap center">
            <?php echo JHtml::_("grid.sort", 'Slug', 'category_slug', $listDirn, $listOrder) ?>
        </th>
        </thead>
        
        
        <tbody>
            <?php foreach ($this->items as $i => $item) { 
                
                $url = JRoute::_('index.php?option=com_myrecart&c=categories&task=edit&id='.$item->id); ?>
            
                <tr class="row<?php echo $i % 2 ?>" >
                    <td class="center"><?php echo $i+1; ?></td>
                    <td class="center">
                        <?php 
                            echo JHtml::_("grid.id", $i, $item->id);
                        ?>
                    </td>
                    <td class="center">
                        <?php 
                            echo JHtml::_("jgrid.published", $item->published, $i);
                        ?>
                    </td>
                    <td class="center">
                        <a href="<?php echo $url ?>" >
                            <?php echo $item->category_name ?>
                        </a> 
                    </td>
                    <td class="center">
                        <a href="<?php echo $url ?>" >
                            <?php echo $item->category_slug ?>
                        </a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
        
    </table>
    
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="boxchecked" value="0" />
    <input type="hidden" name="c" value="category" />
    <input type="hidden" name="filter_order" value="<?php echo $listOrder ?>" />
    <input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn ?>" />
    <?php echo JHtml::_('form.token'); ?>
</form>