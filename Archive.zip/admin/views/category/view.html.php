<?php
defined('_JEXEC') or die;

class MyRECartViewCategory extends JViewLegacy
{
    function display($tpl = null){
        $this->items         = $this->get('Items');
        
        $this->pagination    = $this->get('Pagination');
        $this->state         = $this->get('State');
        $this->addToolbar();
        parent::display($tpl);
    }
    
    function addToolbar(){
        JToolbarHelper::title("Categories");
        
        JToolbarHelper::addNew('add');
        JToolbarHelper::editList('edit');
        JToolbarHelper::deleteList('Are you sure you want to delete this?', 'delete');
        
    }
}