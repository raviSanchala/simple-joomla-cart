<?php
defined('_JEXEC') or die;

class MyRECartViewProduct extends JViewLegacy
{
    function display($tpl = null){
        
        $this->form = $this->get('Form');
        $this->addToolbar();
        
        $document = JFactory::getDocument();
        $document->addStyleSheet(Juri::base().'components/com_myrecart/assets/js/product_page.js');
        
        parent::display($tpl);
    }
    
    function addToolbar(){
        JToolbarHelper::save();
        JToolbarHelper::cancel();
    }
}