<?php
defined('_JEXEC') or die;

class MyRECartViewProduct extends JViewLegacy
{
    function display($tpl = null){
        
        $this->form = $this->get('Form');
        $this->addToolbar();
        parent::display($tpl);
    }
    
    function addToolbar(){
        JToolbarHelper::save();
        JToolbarHelper::cancel();
    }
}