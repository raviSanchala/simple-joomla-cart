<?php
defined('_JEXEC') or die;

JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');

$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));

?>

<form action="<?php echo JRoute::_('index.php?option=com_myrecart&c=products'); ?>" name="adminForm" id="adminForm" method="post">
    <?php if(!empty($this->sidebar)) { ?>
    <div id='j-sidebar-container' class="">
        <?php echo $this->sidebar; $second_class = "class='span10'"; ?>
    </div>
    <?php }else{ 
        $second_class = "class=''";
    } ?>
    
    <div id="j-main-container">
        <div  <?php echo $second_class ?> >
            <div id="filter-bar" class="btn-toolbar">
                <div class="filter-search btn-group pull-left">
                    <input type="text" name="filter_search" id="filter_search" placeholder="Search" value="<?php echo $this->escape($this->state->get('filter.search')) ?>" />
                </div>
                <div class="btn-group pull-left">
                    <button type="submit" class="btn tip" title="Search"><i class="icon-search"></i></button>
                    <button type="button" class="btn tip" onclick="document.id('filter_search').value'';this.form.submit();">
                        <i class="icon-remove"></i>
                    </button>
                </div>
            </div>

        </div>

        <!--<div class="clearfix"></div>-->

        <table class="table table-striped">
            <thead>
            <th width="1%" class="nowrap center">
                #
            </th>
            <th width="1%" class="nowrap center">
                <input type="checkbox" name="checkall-toggle" value="" title="<?php echo JText::_('JGLOBAL_CHECK_ALL') ?>" onclick="Joomla.checkAll(this)" />
            </th>
            <th width="1%" class="nowrap center">
                <?php echo JHtml::_("grid.sort", 'Published', 'published', $listDirn, $listOrder) ?>
            </th>
            <th width="8%" class="nowrap center">
                <?php echo JHtml::_("grid.sort", 'Product Image', 'product_name', $listDirn, $listOrder) ?>
            </th>
            <th class="nowrap center">
                <?php echo JHtml::_("grid.sort", 'Name', 'product_name', $listDirn, $listOrder) ?>
            </th>
            <th class="nowrap center">
                <?php echo JHtml::_("grid.sort", 'Product Price', 'price', $listDirn, $listOrder) ?>
            </th>
            <th class="nowrap center">
                <?php echo JHtml::_("grid.sort", 'Offer Price', 'offer_price', $listDirn, $listOrder) ?>
            </th>
            <th class="nowrap center">
                <?php echo JHtml::_("grid.sort", 'Category Name', 'category_id', $listDirn, $listOrder) ?>
            </th>
            <th class="nowrap center">
                <?php echo JHtml::_("grid.sort", 'Slug', 'product_slug', $listDirn, $listOrder) ?>
            </th>
            </thead>


            <tbody>
                <?php foreach ($this->items as $i => $item) { 

                    $url = JRoute::_('index.php?option=com_myrecart&c=product&task=edit&id='.$item->id); ?>

                    <tr class="row<?php echo $i % 2 ?>" >
                        <td class="center"><?php echo $i+1; ?></td>
                        <td class="center">
                            <?php 
                                echo JHtml::_("grid.id", $i, $item->id);
                            ?>
                        </td>
                        <td class="center">
                            <?php 
                                echo JHtml::_("jgrid.published", $item->published, $i);
                            ?>
                        </td>
                        <td class="center">
                            <a href="<?php echo $url ?>" >
                                <?php 
                                    if($item->product_img != ''){
                                        $product_img_url = HOSTING_IMAGEURL.$item->product_img;
                                    }else{
                                        $product_img_url = HOSTING_IMAGEURL.'default_product_img.png';
                                    }
                                ?>
                                <img style="width:100px; height:100px;" src="<?php echo $product_img_url; ?>"
                            </a> 
                        </td>
                        <td class="center">
                            <a href="<?php echo $url ?>" >
                                <?php echo $item->product_name ?>
                            </a> 
                        </td>
                        <td class="center">
                            <a href="<?php echo $url ?>" >
                                <?php echo number_format($item->price, '2') ?>
                            </a> 
                        </td>
                        <?php if($item->offer_price > 0){
                            $offer_price = $item->offer_price;
                        } else {
                            $offer_price = $item->price;
                        } ?>
                        <td class="center">
                            <a href="<?php echo $url ?>" >
                                <?php echo number_format($offer_price, '2')  ?>
                            </a> 
                        </td>
                        <td class="center">
                            <a href="<?php echo $url ?>" >
                                <?php echo $item->category_name ?>
                            </a>
                        </td>
                        <td class="center">
                            <a href="<?php echo $url ?>" >
                                <?php echo $item->product_slug ?>
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>

        </table>

    </div>
    
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="boxchecked" value="0" />
    <input type="hidden" name="c" value="products" />
    <input type="hidden" name="filter_order" value="<?php echo $listOrder ?>" />
    <input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn ?>" />
    <?php echo JHtml::_('form.token'); ?>
</form>