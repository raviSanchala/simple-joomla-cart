<?php
defined('_JEXEC') or die;

class MyRECartViewProducts extends JViewLegacy
{
    function display($tpl = null){
        
//        $helper = new Helper();
//        $helper->addSubmenu('products');
        
        $this->items         = $this->get('Items');
        $this->pagination    = $this->get('Pagination');
        $this->state         = $this->get('State');
        $this->addToolbar();
        $this->sidebar = JHtmlSidebar::render();
        parent::display($tpl);
    }
    
    function addToolbar(){
        JToolbarHelper::title("Products");
        
        JToolbarHelper::addNew('add');
        JToolbarHelper::editList('edit');
        JToolbarHelper::deleteList('Are you sure you want to delete this?', 'delete');
        
    }
}