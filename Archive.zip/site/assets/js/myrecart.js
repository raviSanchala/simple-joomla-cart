function addToCart(product_id = '0', user_id = '0' ){
    console.log(product_id);
    
    if(user_id > 0){
        
        jQuery.ajax({
            type: "POST",
            url: "index.php?option=com_myrecart&c=products&task=getajaxresponce&format=raw",
            data: {"product_id":product_id, logged_in_user : user_id},
            dataType: "json",
            success: function(data){
               console.log(data);
//               var json_obj = $.parseJSON(data);

               toastr[data.status](data.message);
               document.getElementById("cart_val_ids").value = data.cart_value;
               return false;
            }
        });
    }else{
        window.location.href = "index.php/component/users/?view=login";
        return false;
    }
}

$('.flip').hover(function(){
        $(this).find('.card').toggleClass('flipped');

    });