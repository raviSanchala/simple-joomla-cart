<?php
defined('_JEXEC') or die;


class MyRECartControllersCart extends JControllerLegacy{
    function display($cachable = false, $urlparams = array()){
        JFactory::getApplication()->input->set("view","cart");
        parent::display($cachable, $urlparams);
    }
    
}