<?php
defined('_JEXEC') or die;


class MyRECartControllersCart extends JControllerLegacy{
    function display($cachable = false, $urlparams = array()){
        JRequest::setVar("view","cart");
        parent::display($cachable, $urlparams);
    }
    
}