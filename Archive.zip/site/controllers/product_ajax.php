<?php
// No direct access.
defined('_JEXEC') or die;
 
// Include dependancy of the main controllerform class
jimport('joomla.application.component.controllerform');
 
class MyRECartControllersProduct_ajax extends JControllerLegacy
{
 
   function ajax_cart(){

  $name = JRequest::getVar('view', 'product_ajax');
  //Just print yay for now
   echo "yay";
  exit;
 }
 
}
?>