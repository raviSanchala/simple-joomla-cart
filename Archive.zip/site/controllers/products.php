<?php
defined('_JEXEC') or die;


class MyRECartControllersProducts extends JControllerLegacy{
    function display($cachable = false, $urlparams = array()){
        JFactory::getApplication()->input->set("view","products");
        parent::display($cachable, $urlparams);
    }
    
    public function getajaxresponce(){
        $app = JFactory::getApplication();
        $postData = $app->input->post;

        $product_id = $postData->get('product_id');
        $user_id = $postData->get('logged_in_user');
        
        $session = JFactory::getSession();
        $currentCartVal = $session->get('cart_total_items');
        $model = $this->getModel('products');
        
        $responce_arr = $model->addToCart($product_id, $user_id);
        
        echo json_encode($responce_arr);
        
        die;
        
    }
    
    
}