<?php
defined('_JEXEC') or die;


class MyRECartControllersProducts extends JControllerLegacy{
    function display($cachable = false, $urlparams = array()){
        JRequest::setVar("view","products");
        parent::display($cachable, $urlparams);
    }
    
    public function getajaxresponce(){
        
        $product_id = $_POST['product_id'];
        $user_id = $_POST['logged_in_user'];
        
        $session = JFactory::getSession();
        $currentCartVal = $session->get('cart_total_items');
        $model = $this->getModel('products');
        
        $responce_arr = $model->addToCart($product_id, $user_id);
        
        echo json_encode($responce_arr);
        
        die;
        
    }
    
    
}