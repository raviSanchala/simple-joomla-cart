<?php
defined('_JEXEC') or die;


class MyRECartControllersProducts extends JControllerLegacy{
    function display($cachable = false, $urlparams = array()){
        JRequest::setVar("view","products");
        parent::display($cachable, $urlparams);
    }
    
    public function getajaxresponce(){
        
        $product_id = $_POST['product_id'];
        $user_id = $_POST['logged_in_user'];
        
        $session = JFactory::getSession();
        $currentCartVal = $session->get('cart_total_items');
        
        $db = JFactory::getDbo();
        $user = JFactory::getUser();
        $user_id = $user->id;
        
        $query = $db->getQuery(true);
        
        
        $query->select('*')->from($db->quoteName("#__myrecart_products"))->where($db->quoteName('id')." = ". $product_id );
        $db->setQuery($query);
        $product_arr = $db->loadRow();
        $lastCartId = 0;
        if(count($product_arr) > 0){
            $price = $product_arr['offer_price'];
            $cart_insert_arr = array(
                "product_id"    =>  $product_id,
                "user_id"   =>  $user_id,
                "price" =>  $price,
                "tax"   =>  0,
                "discount"  =>  0,
                "total_price"   =>  $price,
                "createDate"    =>  date("Y-m-d H:i:s"),
            );
            
            $cart_data_obj = (object) $cart_insert_arr;
            $db->insertObject("#__myrecart_cart", $cart_data_obj, 'id');
            $lastCartId = $db->insertid();
        }
        
        if($lastCartId > 0){
            $finalCartVal = $currentCartVal + 1;
            $session->set('cart_total_items', $finalCartVal);
            $responce_arr = array("status"    =>  "success",  "message" => "Product added to cart sucessfully", "cart_value"    =>  $finalCartVal);
        }else{
            $finalCartVal = $currentCartVal;
            $responce_arr = array("status"    =>  "error",  "message" => "Problem occured, to add product in cart", "cart_value"    =>  $finalCartVal);
        }
        echo json_encode($responce_arr);
        
        die;
        
    }
    
    
}