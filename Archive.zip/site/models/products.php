<?php
defined('_JEXEC') or die;

class MyRECartModelProducts extends JModelList
{
    protected function getListQuery(){
        
        $db = $this->getDbo();
        $query = $db->getQuery(true);
        
        $query->select(array('p.*', 'c.category_name', 'pm.product_img'))
                ->from($db->quoteName("#__myrecart_products", 'p'))
                ->join('INNER', $db->quoteName('#__myrecart_categories', 'c') . ' ON (' . $db->quoteName('c.id') . ' = ' . $db->quoteName('p.category_id') . ')')
                ->join('LEFT', $db->quoteName('#__myrecart_product_media', 'pm') . ' ON (' . $db->quoteName('pm.product_id') . ' = ' . $db->quoteName('p.id') . ')')
                ->group($db->quoteName('p.id'));
        $query->order($db->escape($this->getState('list.ordering', 'id')) .' '.$db->escape($this->getState('list.direction', 'ASC')));
        return $query;

    }
    
//    public function getTotalCart(){
//        $db = $this->getDbo();
//        $query = $db->getQuery(true);
//        
//        $query->select('*')
//                ->from($db->quoteName("#__myrecart_cart"));                
//        return $query;
//    }
    
}