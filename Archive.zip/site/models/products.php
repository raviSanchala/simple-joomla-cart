<?php
defined('_JEXEC') or die;

class MyRECartModelProducts extends JModelList
{
    protected function getListQuery(){
        
        $db = $this->getDbo();
        $query = $db->getQuery(true);
        
        $query->select(array('p.*', 'c.category_name', 'pm.product_img'))
                ->from($db->quoteName("#__myrecart_products", 'p'))
                ->join('INNER', $db->quoteName('#__myrecart_categories', 'c') . ' ON (' . $db->quoteName('c.id') . ' = ' . $db->quoteName('p.category_id') . ')')
                ->join('LEFT', $db->quoteName('#__myrecart_product_media', 'pm') . ' ON (' . $db->quoteName('pm.product_id') . ' = ' . $db->quoteName('p.id') . ')')
                ->group($db->quoteName('p.id'));
        $query->order($db->escape($this->getState('list.ordering', 'id')) .' '.$db->escape($this->getState('list.direction', 'ASC')));
        return $query;

    }
    
    public function addToCart($product_id = 0, $user_id = 0){
        $db = JFactory::getDbo();
        $user = JFactory::getUser();
        $user_id = $user->id;
        
        $query = $db->getQuery(true);
        
        $query->select('*')->from($db->quoteName("#__myrecart_products"))->where($db->quoteName('id')." = ". $product_id );
        $db->setQuery($query);
        $product_arr = $db->loadRow();
        $lastCartId = 0;
        if(count($product_arr) > 0){
            $price = $product_arr['offer_price'];
            $cart_insert_arr = array(
                "product_id"    =>  $product_id,
                "user_id"   =>  $user_id,
                "price" =>  $price,
                "tax"   =>  0,
                "discount"  =>  0,
                "total_price"   =>  $price,
                "createDate"    =>  date("Y-m-d H:i:s"),
            );
            
            $cart_data_obj = (object) $cart_insert_arr;
            $db->insertObject("#__myrecart_cart", $cart_data_obj, 'id');
            $lastCartId = $db->insertid();
        }
        
        if($lastCartId > 0){
            $finalCartVal = $currentCartVal + 1;
            $session = JFactory::getSession();
            $session->set('cart_total_items', $finalCartVal);
            $responce_arr = array("status"    =>  "success",  "message" => "Product added to cart sucessfully", "cart_value"    =>  $finalCartVal);
        }else{
            $finalCartVal = $currentCartVal;
            $responce_arr = array("status"    =>  "error",  "message" => "Problem occured, to add product in cart", "cart_value"    =>  $finalCartVal);
        }
        
        return $responce_arr;
    }
    
}