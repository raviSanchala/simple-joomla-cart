<?php

defined('_JEXEC') or die;


if(!defined('DS')){
    define("DS", DIRECTORY_SEPARATOR);
}

require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'global.php';
require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers/helper.php';

$c = JRequest::getVar('c');
if($c == ''){
    $c = "products";
}

$path = JPATH_COMPONENT.DS.'controllers'.DS.$c.'.php';
if(file_exists($path)){
    require_once $path;
}else{
    JError::raiseError("500", JText::_('Junction component').' '.$c.' '.$path ); 
}

$classname = "MyRECartControllers".$c;
$controller = new $classname();


$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();