<?php
defined('_JEXEC') or die;

$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));
$user = JFactory::getUser();
$user_id = $user->id;

$session = JFactory::getSession();
$total_cart_count = 0;
?>

<div class="cart_container">
    <h1> Shopping Cart</h1>
    <div class="row cart_head">
        <div class="col-sm-2 cart_header">Image</div>
        <div class="col-sm-5 cart_header">Description</div>
        <div class="col-sm-2 cart_header">Qty</div>
        <div class="col-sm-2 cart_header">Price</div>
        <div class="col-sm-1 cart_header"></div>
    </div>
    <div class="row cart_item_container">
        <div class="col-sm-2"><img src="http://lorempixel.com/output/technics-q-c-300-300-4.jpg" alt="" class="itemImg" /></div>
        <div class="col-sm-5">
            <div>h1</div>
            <div>adsfdsfsdfsdafsdfds</div>
        </div>
        <div class="col-sm-2">1</div>
        <div class="col-sm-2">$300</div>
        <div class="col-sm-1"><i class="fa fa-amazon"></i></div>
    </div>
    
    <div class="row cart_item_container">
        <div class="col-sm-2"><img src="http://lorempixel.com/output/technics-q-c-300-300-4.jpg" alt="" class="itemImg" /></div>
        <div class="col-sm-5">
            <div>h1</div>
            <div>adsfdsfsdfsdafsdfds</div>
        </div>
        <div class="col-sm-2">1</div>
        <div class="col-sm-2">$300</div>
        <div class="col-sm-1"><i class="fa fa-amazon"></i></div>
    </div>
</div>