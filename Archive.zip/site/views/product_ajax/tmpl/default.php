<?php
defined('_JEXEC') or die;

$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));
?>
<div class="cart_lbl_class" id="cart_lbl_id">Cart()</div>
<div class="row">
    <?php foreach ($this->items as $i => $item ){ ?>
        <div class="col-sm-3">
            <div class="card">
                <img src="img_avatar.png" alt="Avatar" style="width:100%">
                <div class="container">
                  <h4><b><?php echo "22" ?></b></h4> 
                  <p>
                      <button onclick="addToCart(<?php echo $item->id ?>)">Add to Cart</button>
                  </p> 
                </div>
              </div>
        </div>
    <!--<div class="clearfix"></div>-->
    <?php } ?>
    
</div>
<div class="clearfix"></div>