<?php
defined('_JEXEC') or die;

class MyRECartViewProduct_ajax extends JViewLegacy
{
    function display($tpl = null){
        
//        $this->items         = $this->get('Items');
//        $this->pagination    = $this->get('Pagination');
//        $this->state         = $this->get('State');
//        
//        
//        $document = JFactory::getDocument();
//
//        $document->addStyleSheet('components/com_myrecart/assets/css/myrecart.css');
//        $document->addScript('components/com_myrecart/assets/js/myrecart.js');
//
//        parent::display($tpl);
        echo "yessss";
    }
    
}