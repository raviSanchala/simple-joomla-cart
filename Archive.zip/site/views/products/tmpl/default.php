<?php
defined('_JEXEC') or die;

$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));
$user = JFactory::getUser();
$user_id = $user->id;

$total_cart_count = 0;


?>
<!--<div class="cart_lbl_class" id="cart_lbl_id">CART (<span id="cart_val_ids"><?php echo $total_cart_count ?></span>) </div>-->

<?php
foreach ($this->items as $i => $item ){ ?>
        <?php if($item->product_img != ''){
            $product_img = HOSTING_IMAGEURL.$item->product_img;
        }else{
            $product_img = HOSTING_IMAGEURL.'default_product_img.png';
        }
        ?>
        <figure class="snip1423">
            <img src="<?php echo $product_img ?>" class="product_img" alt="sample57" />
          <figcaption>
            <h3><?php echo $item->product_name ?></h3>
            <p><?php echo substr($item->product_name, 0, 25); ?></p>
            <div class="price">
                <?php
                if($item->offer_price > 0){
                    echo '<s>$'.number_format($item->price, '2') .'</s>$'.number_format($item->offer_price, "2") ;
                }else{
                    echo '$'.number_format($item->offer_price, "2");
                }
                ?>
              
            </div>
          </figcaption><i onclick="addToCart(<?php echo $item->id ?>, <?php echo $user_id ?>)" class="ion-android-cart"></i>
          <a href="#"></a>
        </figure>

        
    <!--<div class="clearfix"></div>-->
    <?php } ?>
    
</div>
<div class="clearfix"></div>
<script>
</script>