<?php
defined('_JEXEC') or die;

$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));
$user = JFactory::getUser();
$user_id = $user->id;

$session = JFactory::getSession();
$total_cart_count = 0;
if(empty($session->get('cart_total_items'))){
    $total_cart_count =$this->getTotalCart();
    $session->set('cart_total_items', $total_cart_count);
}

?>
<div class="cart_lbl_class" id="cart_lbl_id">Cart( <span id="cart_val_ids"><?php echo $total_cart_count ?> </span>)</div>











    <?php 
//    echo "<pre>";
//    print_r($this->items);
    foreach ($this->items as $i => $item ){ ?>
        <div class="col-sm-2">
            <div class="card">
                <?php if($item->product_img != ''){
                    $product_img = HOSTING_IMAGEURL.$item->product_img;
                }else{
                    $product_img = '';
                }
                ?>
                <img src="<?php echo $product_img; ?>" alt="Avatar" class="product_img_tag" style="">
                <div class="container">
                    <h4 class="product_name_txt"><b><?php echo $item->product_name; ?></b></h4> 
                  <h5><b><?php echo substr($item->product_name, 0, 10); ?></b></h5> 
                  <p>
                      <button onclick="addToCart(<?php echo $item->id ?>, <?php echo $user_id ?>)">Add to Cart</button>
                  </p> 
                </div>
              </div>
        </div>
    <!--<div class="clearfix"></div>-->
    <?php } ?>
    
</div>
<div class="clearfix"></div>