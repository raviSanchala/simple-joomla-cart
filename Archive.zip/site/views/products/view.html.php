<?php
defined('_JEXEC') or die;

class MyRECartViewProducts extends JViewLegacy
{
    function display($tpl = null){
        
        $this->items         = $this->get('Items');
        $this->pagination    = $this->get('Pagination');
        $this->state         = $this->get('State');
        
        
        $document = JFactory::getDocument();
        
        
        $document->addStyleSheet('//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css');
        $document->addStyleSheet('components/com_myrecart/assets/css/myrecart.css');
        
        
        $document->addScript('//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js');
        $document->addScript('//code.jquery.com/jquery-1.11.1.min.js');
        $document->addScript('components/com_myrecart/assets/js/myrecart.js');
        
        $document->addScript('//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css');
        
        $document->addScript('//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js');
        $document->addScript('//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js');

        parent::display($tpl);
    }
    
}